package com.eric.karschner.ultimatetictactoe.viewmodel

import androidx.lifecycle.ViewModel
import com.eric.karschner.ultimatetictactoe.model.Game
import com.eric.karschner.ultimatetictactoe.model.Player

class GameViewModel: ViewModel() {

    private val game = Game()
    lateinit var player1: Player
    lateinit var player2: Player

    fun setupGame2Players(name1:String, symbol1:String, name2:String, symbol2:String){
        player1 = Player(name1, symbol1)
        player2 = Player(name2, symbol2)
        promptMove(player1)
    }

    fun promptMove(player: Player){

    }

    fun getBoardState() = game.board.display()
}