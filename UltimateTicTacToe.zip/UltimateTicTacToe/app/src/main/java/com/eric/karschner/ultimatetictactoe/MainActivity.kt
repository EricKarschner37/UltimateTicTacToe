package com.eric.karschner.ultimatetictactoe

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import com.eric.karschner.ultimatetictactoe.viewmodel.GameViewModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val binding: com.eric.karschner.ultimatetictactoe.databinding.ActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        val mViewModel = ViewModelProviders.of(this).get(GameViewModel::class.java)
        mViewModel.setupGame2Players("Eric", "X", "OtherEric", "O")
    }
}
